[ output_signal ] = Extract_RMS(input_signal)

% function: Short description
%
% Extended description
output_signal = rms(input_signal, length(input_signal));


end  % function

[ out ] = Extract_WL( in )
% function: Short description
%
% Extended description


end  % function

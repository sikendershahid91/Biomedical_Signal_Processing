You have 2 channel EEG C3 and C4 electrode positions.
The Subject moved his left or right hand in each trial.
There are 131 training trials and 126 testing trials.
The class lables of each trial is given in label_train and label_test variables
The EEG data starts 3 seconds before the movement and extends 5 sec after the movement
The movement execution is started at sample 750 and terminated at sample 1000.

Your aim is to use the information in training data and classify the test eeg data.
